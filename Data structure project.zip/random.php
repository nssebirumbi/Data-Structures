<?php
function randomnumbers(){
$random = array();
for ($i=0; $i < 1000; $i++) { 
	$random[$i] = rand()%1000;
}
return $random;
}
?>