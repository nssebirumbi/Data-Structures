<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Data Structures</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<div class="sidebar" data-background-color="black" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Data Structures" width="220" height="61" style="position: relative;">
            </div>

            <ul class="nav">
                <li>
                    <a href="index.html">
                        <i class="ti-panel"></i>
                        <p>Home</p>
                    </a>
                </li>
               <li class="treeview">
                    <a href="recursive.php"><span>Recursive Data Structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li >
                    <a href="dstructure.php"><span>elementary data structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="sortalg.php"><span>sorting</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="searchalg.php"><span>searching</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li> 
                <li class="treeview">
                    <a href="trees.php"><span>Trees and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="active">
                    <a href="graphs.php"><span>graphs and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

   <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    

                </div>
                <h1>Data Structures And Algorithms</h1>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class='navbar-center' style='font-size:1.2em; margin-top: -30px; margin-bottom: 0px; '>
                                <ul class="nav navbar-nav " style="background-color: black; color: white; text-decoration: none; padding-top: 3px; padding-bottom: 3px;">
                                    <li style="border-right: 1px solid white;"><a href="Breadth-First Search.html">Breadth first search</a></li>
                                    <li style="border-right: 1px solid white;"><a href="Dijkstra Visualzation.html">Dijkstra Visualization</a></li>
                                    <li style="border-right: 1px solid white;"><a href="Kruskal MST Visualzation.html">Kruskals Visualization</a></li>
                                    <li style="border-right: 1px solid white;"><a href="Prim MST Visualzation.html">Prims Visualzation</a></li>
                                </ul>
                               <br><br><br>
                           
                            <div class="content all-icons">
                        	    <h2 class="title">Graph Data Structure</h2>
                        	    <p>

Mathematical graphs can be represented in data structure. We can represent a graph using an array of vertices and a two-dimensional array of edges. Before we proceed further, let's familiarize ourselves with some important terms −

   <li> Vertex − Each node of the graph is represented as a vertex. In the following example, the labeled circle represents vertices. Thus, A to G are vertices. We can represent them using an array as shown in the following image. Here A can be identified by index 0. B can be identified using index 1 and so on.</li>

   <li> Edge − Edge represents a path between two vertices or a line between two vertices. In the following example, the lines from A to B, B to C, and so on represents edges. We can use a two-dimensional array to represent an array as shown in the following image. Here AB can be represented as 1 at row 0, column 1, BC as 1 at row 1, column 2 and so on, keeping other combinations as 0.</li>

    <li>Adjacency − Two node or vertices are adjacent if they are connected to each other through an edge. In the following example, B is adjacent to A, C is adjacent to B, and so on.</li>

   <li> Path − Path represents a sequence of edges between the two vertices. In the following example, ABCD represents a path from A to D.</li>
</p>
                        	  
                                    <img src="graph.jpg">
                                   


                        	</div>
                          </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by Incubee
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
