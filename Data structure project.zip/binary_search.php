<?php
session_start();
include "random.php";
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Data Structures</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<div class="sidebar" data-background-color="black" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Data Structures" width="220" height="61" style="position: relative;">
            </div>

            <ul class="nav">
                <li>
                    <a href="index.html">
                        <i class="ti-panel"></i>
                        <p>Home</p>
                    </a>
                </li>
               <li class="treeview">
                    <a href="recursive.php"><span>Recursive Data Structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li >
                    <a href="dstructure.php"><span>elementary data structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="sortalg.php"><span>sorting</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="active">
                    <a href="searchalg.php"><span>searching</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li> 
                <li class="treeview">
                    <a href="trees.php"><span>Trees and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="graphs.php"><span>graphs and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
            </ul>
    	</div>
    </div>
     <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    

                </div>
                <h1>Data Structures And Algorithms</h1>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="col-md-8">
                            <div class='navbar-center' style='font-size:1.2em; margin-top: -30px; margin-bottom: 0px; '>
                                <ul class="nav navbar-nav " style="background-color: black; color: white; text-decoration: none; padding-top: 3px; padding-bottom: 3px;">
                                    
                                    <li style="border-right: 1px solid white;"><a href="binary_search.php">Binary search</a></li>
                                    <li style="border-right: 1px solid white;"><a href="Binary and Linear Search Visualization.html">Searching visualization</a></li>
                                </ul>
                            </div>
                            <div class="content all-icons">
                            <?php
                            	echo"
                            	<br><br><br><br>
                            	<p> Upload a csv file or use the random numbers generated below</p>
								<form method='POST' action='?''>
									<input type='file' name='csv' value='upload Csv file'>
									<input type='submit' name='upload' value='Upload File'>
									<br>
									<p>Enter a search value </p>
									<input type='text' name='searchn' >
									<input type='submit' value='search' name='search'>
								</form>
								";
								if(isset($_POST['upload'])){
								    $csv=$_POST['csv'];
								    $handle = fopen($csv, "r");
								    $data = fgetcsv($handle);
								    $_SESSION['arr4']=$data;
								}

								function display1($array2){
									echo "<div class='arrayprint' >";
									echo "<table border=1>
											<tr>";
									foreach ($array2 as $key => $value) {
										if ($key%24==0) {

                                            echo "</tr>";
                                            echo "<tr>";
                                        }
                                             echo "
                                            <td>$value</td>
                                            ";
                                        }
                                        echo "</tr></table></div>";
								}

								function binarySearch($value, &$array3, $start, $end){
								    if($end<$start) return -1;
								    
								    $middle = floor(($end + $start)/2);
								    if($array3[$middle]==$value) 
								    	return $middle;
								    elseif ($array3[$middle] > $value) 
								    	return binarySearch($value, $array3, $start, $middle-1);
								    else return binarySearch($value, $array3, $middle+1, $end);
								}
								 if(isset($_POST['upload'])){
                                    $new_data=array();
                                    $new_data=$_SESSION['arr4'];
                                    sort($new_data);
                                   // display1($new_data);
                                   }elseif(!isset($_POST['upload']) ){
                                        $_SESSION['arr4']=randomnumbers();
                                        $new_data=array();
                                        $new_data=$_SESSION['arr4'];
                                        sort($new_data);
                                       // display1($new_data);
                                           }
                                	if(isset($_POST['searchn'])){
									$Searchvalue=$_POST['searchn'];
									$start_time=microtime(true);
								    $found = binarySearch($Searchvalue,$new_data, 0, sizeof($new_data)-1);
								    $end_time=microtime(true);
								    $time=$end_time-$start_time;
								    $time = ($time*0.000001);
								    
								    if(isset($_POST['search']) && $found!=-1){
								        echo "<h3> $Searchvalue found at position $found </h3>";
								        echo "<h3>Execution time of the Binary search is $time seconds </h3>";
								    	//display1($new_data);
								    	
								    }
									elseif(isset($_POST['search']) && $found== -1){
										echo "<h3>Search value not found<h3>";
										//display1($new_data);
									}
								}
								
                                if(isset($_POST['upload'])){
                                  
                                    display1($new_data);
                                   }elseif(!isset($_POST['upload']) ){
                                       
                                        display1($new_data);
                                           }
                                   
							
								
							
								?>
                        	</div>
                        	</div>
                        	<div class="col-md-4">
                        	    <img src="assets/gifs/binary-and-linear-search-animations.gif" style="width: 350px; height: 300px;"><br>
                        	    <h3>Binary Search</h3>
								<em>A binary search splits the list into two equal sub divisions
								and a search is made in one of the halves. <br/>The comparisons made are using an ordered list
								The middle term is examined first, if the term is the search item then the search is done.<br/>
								If the item needed is greater than the middle item then the lower half including the middle item is 
								droped and the upper part is considered and divided again, the search is being continuously done until 
								when the search item is located
								<h3>Algorithm for a Binary Search</h3>
								found = 0, location = NULL<br/>
									While(L <= U) AND (found = 0), do<br/>
										mid = ((L+U)/2)<br/>
										If(KEY = A[mid]), then<br/>
											found  = 1 <br/>
											location = mid<br/>
										Else<br/>
											If(KEY > A[mid]), then<br/>
												L = mid + 1 <br/>
											Else
											U = mid – 1'<br/>
											EndIf<br/>
										EndIf<br/>
									EndWhile<br/>
									If(found = 0)<br/>
										print “Search Unsuccessful”<br/>
									Else<br/>
										print “Search Successful”<br/>
									EndIf<br/>
									Return(location)<br/>
									Stop<br/></em>
                        	</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by Incubee
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
