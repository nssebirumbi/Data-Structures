<?php
session_start();

include "stuck.php";
if (!isset($_SESSION['arr1'])){
	$stack=new Stack();
	$_SESSION['arr1']=serialize($stack);

	}

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Data Structures</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<div class="sidebar" data-background-color="black" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Data Structures" width="220" height="61" style="position: relative;">
            </div>

            <ul class="nav">
                <li>
                    <a href="index.html">
                        <i class="ti-panel"></i>
                        <p>Home</p>
                    </a>
                </li>
               <li class="treeview">
                    <a href="recursive.php"><span>Recursive Data Structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="active">
                    <a href="dstructure.php"><span>elementary data structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="sortalg.php"><span>sorting</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="searchalg.php"><span>searching</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li> 
                <li class="treeview">
                    <a href="trees.php"><span>Trees and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li >
                    <a href="graphs.php"><span>graphs and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

     <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    

                </div>
                <h1>Data Structures And Algorithms</h1>
            </div>
        </nav>


        <div class="content">
            <ul class="nav navbar-nav " style="background-color: black; color: white; text-decoration: none; padding-top: 3px; padding-bottom: 3px;">
                    <li style="border-right: 1px solid white;"><a href="ds.php">Queue</a></li>
                    <li style="border-right: 1px solid white;"><a href="stack.php">Stack</a></li>
                    <li style="border-right: 1px solid white;"><a href="Linked List Stack Visualization.html">Linked lists</a></li>
                    <li style="border-right: 1px solid white;"><a href="Array Stack Visualization.html">Stacks visualization</a></li>
                    <li style="border-right: 1px solid white;"><a href="Array Queue Visualization.html">Queues visualization</a></li>
                </ul>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="col-md-8">
                                <div class="header">
                                    
                                </div>
                                <div class="content all-icons">
                                    <form method="POST" action="?">
                                		<div class="input-group input-group-sm">
                                			 <input type="text" class="form-control" placeholder="Enter value" name="val" required>	
                                			 <span class="input-group-btn"><button class="btn btn-primary" type="submit" name="push">Push</button></span>
                                		</div>
                                	</form>
                                	<br>
                                	<form method="POST" action="">
                                		<input type="submit" class="btn btn-primary" value="pop" name="pop">
                                	</form>
                                	
                                	<?php
                                        function insertIntoQueue($value){
                                        	$stak= unserialize($_SESSION['arr1']);
                                        	$stak->push($value);
                                        	$_SESSION['arr1']=serialize($stak);
                                        }
                                        function removeFromQueue(){
                                        	$stuk=unserialize($_SESSION['arr1']);
                                        	$stuk->pop();
                                        	$_SESSION['arr1']=serialize($stuk);
                                        }
                                        if(isset($_POST['push'])){
                                        	$val=$_POST['val'];
                                        	
                                        	insertIntoQueue($val);
                                        }
                                        elseif(isset($_POST['pop'])){
                                        	removeFromQueue();
                                        }
                                        function printValues(){
                                        	$final_arr1=unserialize($_SESSION['arr1']);
                                        	$final_arr1->getvalues();
                                        	$_SESSION['arr1']=serialize($final_arr1);
                                        }
                                        
                                        printValues();
                                        ?>
                            	</div>
                        	</div>
                        	<div class="col-md-12">
                        	    
                        	</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by Incubee
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
