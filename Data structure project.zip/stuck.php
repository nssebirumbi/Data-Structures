<?php
class Stack {
	public $item=10;
	public $size=array();
	public $point=0;

	public function push($data){
		if($this->point>=$this->item){
			echo "stack is overflow and more values cant be enter";
		}else{
			$this->size[$this->point]=$data;
			$this->point++;
		}
	}
	public function pop(){
		if(empty($this->size)){
			echo "stack is empty";
		}else{
			array_pop($this->size);
			$this->point--;
		}
	}
	public function top() {
        echo current($this->$size);
    }
    public function getvalues(){
$siz=sizeof(($this->size));
echo "<h3>Values in a stack</h3>";
echo "<table border=1>

  <tr>
";
for ($i=0; $i <$siz ; $i++) { 
  echo "
     <td>".$this->size[$i]."</td>
    ";
}
echo "
</tr>
</table>";
 }
}


?>

