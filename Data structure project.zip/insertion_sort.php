
<?php
/*<br />
*Function for sorting an array with insertion sort algorithms<br />
*/
@session_start();
include "random.php";
function sortInsertion($array) {
   $sortedArray = array();
    for ($i = 0 ; $i<count($array); $i++) {
        $element = $array[$i];
        $j = $i;
       while($j >0 && $sortedArray[$j-1]> $element) {
           $sortedArray[$j] = $sortedArray[$j-1];
            $j = $j-1;
        }
        $sortedArray[$j] = $element;
    }
    return $sortedArray;
}
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Data Structures</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<div class="sidebar" data-background-color="black" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Data Structures" width="220" height="61" style="position: relative;">
            </div>

            <ul class="nav">
                <li>
                    <a href="index.html">
                        <i class="ti-panel"></i>
                        <p>Home</p>
                    </a>
                </li>
               <li class="treeview">
                    <a href="recursive.php"><span>Recursive Data Structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li >
                    <a href="dstructure.php"><span>elementary data structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="active">
                    <a href="sortalg.php"><span>sorting</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="searchalg.php"><span>searching</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li> 
                <li class="treeview">
                    <a href="trees.php"><span>Trees and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="graphs.php"><span>graphs and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

     <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    

                </div>
                <h1>Data Structures And Algorithms</h1>
            </div>
        </nav>


        <div class="content">
            <div class='navbar-center' style='font-size:1.2em; margin-top: -30px; margin-bottom: 0px; '>
                <ul class="nav navbar-nav " style="background-color: black; color: white; text-decoration: none; padding-top: 3px; padding-bottom: 3px;">
                    <li style="border-right: 1px solid white;"><a href="selection_sort.php">Selection sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="quick_sort.php">Quick sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="merge.php">Merge sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="bubble.php">Bubble sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="insertion_sort.php">Insertion sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="Comparison Sorting Visualization.html">Sorting visualization</a></li>
                </ul>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="col-md-9">
                            <h3>Before sorting</h3>
							<form method="POST" action="?"  style="width: 400px;">
								<div class="input-group input-group-sm">
									 <span class="input-group-btn"><button class="btn btn-primary" type="submit" name="sort">Insertion sort</button></span>
								</div>
							</form>
                            	<p> Upload a csv file or use the random numbers generated below</p>
							<form method="POST" action="?">
								<input type="file" name="csv" value="upload Csv file">
								<input type="submit" name="upload" value="Upload File">
								
							</form>
                            <div class="content all-icons">
                    
								<?php
								if(isset($_POST['upload'])){
								    $csv=$_POST['csv'];
								    $handle = fopen($csv, "r");
								    $data = fgetcsv($handle);
								    $_SESSION['arr04']=$data;
								}
								if(isset($_POST['upload'])){
								display($_SESSION['arr04']);
								   }else{   
                                         $_SESSION['arr04']=randomnumbers();    
                                           } 
                                if(!isset($_POST['sort'])){
                                    echo "<h3>Before sorting with Quick sort</h3>";
                                    display($_SESSION['arr04']);
                                }

								function display($array2){
									echo "<div class='arrayprint' >";
									echo "<table border=1>
											<tr>";
									foreach ($array2 as $key=>$value) {
										if ($key%24==0) {

								            echo "</tr>";
								            echo "<tr>";
								        }
								         echo "
								        <td>$value</td>
								        ";
								    }
								    echo "</tr></table></div>";
								}

								 if(isset($_POST['sort'])){
									$Sorted=$_POST['sort'];
									$new_data=$_SESSION['arr04'];

                                    $start_time=microtime(true);
								    $found = sortInsertion($new_data);
                                    $end_time=microtime(true);
                                    $time=$end_time-$start_time;
                                    $time=($time*0.000001);

								    if(isset($found)) {
								    	echo "<h3>After sorting with Insertion sort</h3>";
								    	echo "<table border=1>
								            <tr>
								            <td colspan='24'><h3>Execution time is $time seconds</h3></td>
								            </tr>
											<tr>";
										foreach ($found as $key=>$values) {
											if ($key%21==0) {

									            echo "</tr>";
									            echo "<tr>";
									        }
									         echo "
									        <td>$values</td>
									        ";
									    }
									    echo "</tr></table></div>";
									}
								}else{
    
                                        $randnums=$_SESSION['arr04'];
                                        $found2=sortInsertion($randnums);
                                        if(isset($_POST['sort']) &&isset($found2)){
                                            echo "<h3>After sorting with Insertion sort</h3>";
                                            $_SESSION['arr04']=$found2;
                                            display($found2);
                                    }
                                } 	
								?>
                        	</div>
                        	</div>
                        	<div class="col-md-3">
                            <h3>Insertion Sort</h3>
                            <h4>Algorithm</h4>
                            <p>
                            B[1] = A[1]<br/>
                            For i = 2 to n, do<br/>
                            //Pick the element <br/>
                            KEY = A[ i ] <br/>

                            //Find appropriate location by comparison  <br/>
                            location = i        <br/>
                            While(location > 1) AND (KEY < B[location-1]), do <br/>
                            location = location - 1  <br/>
                            EndWhile <br/>

                            //Shift elements if required<br/>
                            j = i   <br/>
                            While( j > location )   <br/>
                            B[ j ] = B [ j – 1 ]  <br/>
                            j = j - 1       <br/>
                            EndWhile       <br/>

                            //Place the element <br/>
                            B[location] = KEY <br/>
                            EndFor <br/>
                            </p>
                            <h4>Description</h4>
                            <p>
                            Insertion sort iterates, consuming one input element each repetition, and growing 
                                a sorted output list. Each iteration, insertion sort removes one element from the input data, 
                                finds the location it belongs within the sorted list, and inserts it there. It repeats until no input elements remain.
                            Sorting is typically done in-place, by iterating up the array, growing the sorted list behind it. At each array-position,
                             it checks the value there against the largest value in the sorted list (which happens to be next to it, in the previous 
                                array-position checked). If larger, it leaves the element in place and moves to the next. If smaller, it finds the 
                            correct position within the sorted list, shifts all the larger values up to make a space, and inserts into that correct position.
                            The resulting array after k iterations has the property where the first k + 1 entries are sorted (+1 because the first entry is skipped).
                             In each iteration the first remaining entry of the input is removed, and inserted into the result at the correct position, thus extending
                              the result:
                                              </p>
                                              <p>
                        </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by Incubee
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
