<?php
class Queue{
 private $queue = NULL;
 private $limit;
 function __construct($limit = 100){
   $this->queue = array();
   $this->limit = $this->getLimit($limit);
 }
 function enqueue($item){
   $isSizeSmallerThanLimit = (count($this->queue) < ($this->limit));
   if($isSizeSmallerThanLimit) {
        //array_push($this->queue,$item);
    $this->queue[count($this->queue)]=$item;
   }else {
        echo "<h5>Queue is already full</h5>";
   }
 }
 function dequeue(){
    if(!empty($this->queue)){
        $frontItem   = array_shift($this->queue);
        return $frontItem;
    } else {
        echo "<h5>Queue is empty....Try enqueuing values in the queue</h5>";
    }
 }
 function isEmpty(){
     $isEmpty = empty($this->queue);
     return $isEmpty;
 }
 function size(){
    $size = count($this->queue);
    return $size;
 }
 function getLimit($limit){
  parse_str($limit);
    return $limit;  
 }
 function getvalues(){
//print_r($this->queue);
if(isset($_POST['enque'])){
    echo "<h3>Values in a queue</h3>";
}
$size=count($this->queue);
echo "<table border=1>

  <tr>
";
for ($i=0; $i <$size ; $i++) { 
  echo "
     <td>".$this->queue[$i]."</td>
    ";
}
echo "
</tr>
</table>";
 }
}
?>
