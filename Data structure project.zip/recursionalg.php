<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Data Structures</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<div class="sidebar" data-background-color="black" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Data Structures" width="220" height="61" style="position: relative;">
            </div>

            <ul class="nav">
                <li>
                    <a href="index.html">
                        <i class="ti-panel"></i>
                        <p>Home</p>
                    </a>
                </li>
               <li class="active">
                    <a href="recursive.php"><span>Recursive Data Structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li >
                    <a href="dstructure.php"><span>elementary data structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="sortalg.php"><span>sorting</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="searchalg.php"><span>searching</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li> 
                <li class="treeview">
                    <a href="trees.php"><span>Trees and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="graphs.php"><span>graphs and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    

                </div>
                <h1>Data Structures And Algorithms</h1>
            </div>
        </nav>


       <div class="content">
            <div class='navbar-center' style='font-size:1.2em; margin-top: -30px; margin-bottom: 0px; '>
                <ul class="nav navbar-nav " style="background-color: black; color: white; text-decoration: none; padding-top: 3px; padding-bottom: 3px;">
                    <li style="border-right: 1px solid white;"><a href="recursionalg.php">Factorial & Fibonacci</a></li>
                </ul>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form method="POST" action="?">
	<select name="recurs" class="btn btn-primary">
		<option name="fibo">fibonacci</option>
		<option name="facto">factorial</option>
	</select>
	<input  class="btn btn-primary"  type="text" name="value">
	<input type="submit" class="btn btn-primary" name="getValue" value="Generate Value">
</form>

        <?php 
        function factorial($n){
        	if($n==0){
        		return 1;
        	}
        	else{
        		return $n*factorial($n-1);
        	}
        }
        function fib($n){
        	if($n==0){
        		return 0;
        	}
        	elseif($n==1){
        		return 1;
        	}
        	else{
        		return fib($n-1)+fib($n-2);
        	}
        }
        @$select1=$_POST['recurs'];
        @$select2=$_POST['recurs'];
        if($select1=="factorial"){
        	$val=$_POST['value'];
        	$display_values=factorial($val);
        	echo($display_values);
        }
        elseif($select2=="fibonacci"){
        	$val=$_POST['value'];
        	$display_values=fib($val);
        	echo($display_values);
        
        }
        else{
        	echo("cant generate values");
        }
        ?><br><br>
        <h2 class="title">Fibonacci </h2>
        <p>Fibonacci series generates the subsequent number by adding two previous numbers. Fibonacci series starts from two numbers − F0 & F1. The initial values of F0 & F1 can be taken 0, 1 or 1, 1 respectively.
            <br><br>F<sub>n</sub> = F<sub>n-1</sub> + F<sub>n-2</sub>
            </p>
        <h4 class="title">Fibonacci illustration</h4>
        <img src="fibonacci_animation.gif">
<h4 class="title">Fibonacci Recursive Algorithm<h4>
    <p class="title">START<br>
Procedure Fibonacci(n)<br>
   declare f<sub>0</sub>, f<sub>1</sub>, fib, loop <br>
   
   set f<sub>0</sub> to 0<br>
   set f<sub>1</sub> to 1<br>
   
   <b>display f<sub>0</sub>, f<sub>1</sub></b><br>
   
   for loop &larr; 1 to n<br>
   
      fib &larr; f<sub>0</sub> &plus; f<sub>1</sub>  <br> 
      f<sub>0</sub> &larr; f<sub>1</sub><br>
      f<sub>1</sub> &larr; fib<br>

      <b>display fib</b><br>
   end for<br>

END</p>
<h2 class="title">Factorial </h2>
<h4 class="title">Factorial Algorithm</h4>
<p class="title">
<pre><strong>Step 1:</strong> Start
<strong>Step 2:</strong> Read number <i>n</i>
<strong>Step 3:</strong> Call factorial(n)
<strong>Step 4:</strong> Print factorial f
<strong>Step 5: </strong>Stop
factorial(n)
<strong>Step 1:</strong> If n==1 then return 1
<strong>Step 2:</strong> Else 
f=n*factorial(n-1)
<strong>Step 3: </strong>Return f</pre></p>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by Incubee
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
