<?php
	session_start();

	$c = mysqli_connect("localhost","id3000422_nssebirumbi","ichadsuubi");
   
	$db = mysqli_select_db($c,"id3000422_project");
     
    
	if (isset($_POST['login'])) {
	    
    $un = $_POST['un'];
    $pwd = $_POST['pwd'];

    $sql = mysqli_query($c,"select username,password from login where username='$un' AND password='$pwd'");

    if ($row = mysqli_fetch_assoc($sql)) {
	    $_SESSION['un'] = $un;
	    //$_SESSION['success'] = "You are logged in";
	    header("Location:welcome.html");
    }
    

    else
      
    header("Location:index.html");
  }
?>