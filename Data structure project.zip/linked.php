<?php
@session_start();
@include "implementationDLL.php";

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>Data Structures</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="black" data-active-color="danger">

    <!--
        Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
        Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Data Structures" width="220" height="61" style="position: relative;">
            </div>

            <ul class="nav">
                <li>
                    <a href="index.html">
                        <i class="ti-panel"></i>
                        <p>Home</p>
                    </a>
                </li>
               <li class="treeview">
                    <a href="recursive.php"><span>Recursive Data Structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="active">
                    <a href="dstructure.php"><span>elementary data structures</span>
                    </a>
                </li>
                <li>
                    <a href="sortalg.php"><span>sorting</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="searchalg.php"><span>searching</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li> 
                <li class="treeview">
                    <a href="trees.php"><span>Trees and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="graphs.php"><span>graphs and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    

                </div>
                <h1>Data Structures And Algorithms</h1>
            </div>
        </nav>


        <div class="content">
            <div class='navbar-center' style='font-size:1.2em; margin-top: -30px; margin-bottom: 0px; margin-left: -15px;'>
                <ul class="nav navbar-nav " style="background-color: black; color: white; text-decoration: none; padding-top: 3px; padding-bottom: 3px;">
                    <li style="border-right: 1px solid white;"><a href="#">Doublely linked lists</a></li>
                    <li><a href="#">Singly linked lists</a></li>
                </ul>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="col-md-9">
                                <form method="POST" action="?"  style="width: 400px;">
                                    <div class="input-group input-group-sm">
                                         <input type="text" class="form-control" placeholder="Enter value" name="val" required> 
                                         <span class="input-group-btn"><button class="btn btn-primary" type="submit" name="enque">Add Value</button></span>
                                    </div>
                                </form>
                                <br> <br> <br>
                                <form method="POST" action="?">
                                    <input type="text" class="form-control" placeholder="Enter value" name="val" required>  
                                    <input type="submit" class="btn btn-primary" value="Remove Value" name="deque">
                                </form>
                                <br> <br> <br>
                                <form method="POST" action="?">
                                    <input type="text" class="form-control" placeholder="value after" name="valueafter" required>
                                    <input type="text" class="form-control" placeholder="newvalue" name="newvalue" required>
                                    <input type="submit" class="btn btn-primary" value="insert Value any where" name="insert">
                                </form>
                                <br> <br> <br>
                                <form method="POST" action="?">
                                    <input type="text" class="form-control" placeholder="Enter value to search" name="searchvalue" required>    
                                    <input type="submit" class="btn btn-primary" value="search" name="value">
                                </form>
                                <?php
                                    
                                    if (!isset($_SESSION['arr22'])){
                                        $newDLList = new DoublyLinkedList();
                                        $_SESSION['arr22']=serialize($newDLList);
                                    
                                    }
                                    
                                function insertIntoLists($value){
                                    
                                    $newDLList = unserialize($_SESSION['arr22']);
                                    $newDLList->add($value);
                                    $_SESSION['arr22']=serialize($newDLList);
                                    
                                }
                                function find($value){
                                    
                                    $newDLList = unserialize($_SESSION['arr22']);
                                    $newDLList->find($value);
                                    $_SESSION['arr22']=serialize($newDLList);
                                    
                                }

                                function insertafterLists($valueAfter,$newValue){
                                    
                                    $newDLList = unserialize($_SESSION['arr22']);
                                    $newDLList->insert($valueAfter, $newValue);
                                    $_SESSION['arr22']=serialize($newDLList);
                                    
                                }

                                function removeFromLists($value){
                                    
                                    $newDLList= unserialize($_SESSION['arr22']);
                                    $newDLList->removeNode($value);
                                    $_SESSION['arr22']=serialize($newDLList);
                                }

                                if(isset($_POST['enque'])){
                                    $val=$_POST['val'];
                                    insertIntoLists($val);
                                }
                                elseif(isset($_POST['deque'])){
                                    $val=$_POST['val'];
                                    removeFromLists($val);
                                }
                                elseif(isset($_POST['insert'])){
                                    $nval=$_POST['newvalue'];
                                    $aval=$_POST['valueafter'];
                                    insertafterLists($aval,$nval);
                                }
                                elseif(isset($_POST['value'])){
                                    $nval=$_POST['searchvalue'];
                                    //$aval=$_POST['valueafter'];
                                    find($nval);
                                }
                                function printValue(){
                                    //$newList = new SinglyLinkedList();
                                    $final_arr=unserialize($_SESSION['arr22']);
                                    $final_arr->printValues();
                                    $_SESSION['arr22']=serialize($final_arr);
                                }
                                printValue();
                                ?>
                            </div>
                        <div class="col-md-3">
                           
                        </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by Incubee
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Checkbox, Radio & Switch Plugins -->
    <script src="assets/js/bootstrap-checkbox-radio.js"></script>

    <!--  Charts Plugin -->
    <script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
    <script src="assets/js/paper-dashboard.js"></script>

    <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="assets/js/demo.js"></script>


</html>
