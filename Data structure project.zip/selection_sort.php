<?php
 session_start();
 include "random.php";
function selectionSort($data)
{
    $n=count($data);
    $nextSwap=null;     //the index of next min value or max value
    $temp=null;
 
    for($i=0; $i<$n-1; $i++)//outer loop
    {
 
        $nextSwap=$i;
        for($j=$i+1; $j<$n; $j++)//inner loop
        {
            if( $data[$j]<$data[$nextSwap] ) //change the < to > for descending order
            {
                $nextSwap=$j; 
            }
        }
 
        //swap the current index of the outer loop with the next min value
        $temp=$data[$i];
        $data[$i]=$data[$nextSwap];
        $data[$nextSwap]=$temp;
    }
 
    return $data;
}
 ?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>Data Structures</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="black" data-active-color="danger">

    <!--
        Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
        Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <img src="assets/img/logo.jpg" alt="Data Structures" width="220" height="61" style="position: relative;">
            </div>

            <ul class="nav">
                <li>
                    <a href="index.html">
                        <i class="ti-panel"></i>
                        <p>Home</p>
                    </a>
                </li>
               <li class="treeview">
                    <a href="recursive.php"><span>Recursive Data Structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li >
                    <a href="dstructure.php"><span>elementary data structures</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="active">
                    <a href="sortalg.php"><span>sorting</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="searchalg.php"><span>searching</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li> 
                <li class="treeview">
                    <a href="trees.php"><span>Trees and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
                <li class="treeview">
                    <a href="graphs.php"><span>graphs and Tree algorithm</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    

                </div>
                <h1>Data Structures And Algorithms</h1>
            </div>
        </nav>


        <div class="content">
            <div class='navbar-center' style='font-size:1.2em; margin-top: -30px; margin-bottom: 0px; '>
                <ul class="nav navbar-nav " style="background-color: black; color: white; text-decoration: none; padding-top: 3px; padding-bottom: 3px;">
                    <li style="border-right: 1px solid white;" class="active"><a href="selection_sort.php">Selection sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="quick_sort.php">Quick sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="merge.php">Merge sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="bubble.php">Bubble sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="insertion_sort.php">Insertion sort</a></li>
                    <li style="border-right: 1px solid white;"><a href="Comparison Sorting Visualization.html">Sorting visualization</a></li>
                </ul>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="col-md-9">
                            <h3>Before sorting</h3>
                            <form method="POST" action="?"  style="width: 400px;">
                                    <div class="input-group input-group-sm">
                                         <span class="input-group-btn"><button class="btn btn-primary" type="submit" name="sort">Selection sort</button></span>
                                    </div>
                                </form>
                                <br>
                            	<p> Upload a csv file or use the random numbers generated below</p>
                            <form method="POST" action="?">
                                <input type="file" name="csv" value="upload Csv file">
                                <input type="submit" name="upload" value="Upload File">
                                
                            </form>
                            
                            <div class="content all-icons">
                               <?php
                                    if(isset($_POST['upload'])){
                                        $csv=$_POST['csv'];
                                        $handle = fopen($csv, "r");
                                        $data = fgetcsv($handle);
                                        $_SESSION['arr01']=$data;
                                    }
                                    if(isset($_POST['upload'])){
                                    display($_SESSION['arr01']);
                                       } elseif(!isset($_POST['sort'])){
                                            echo "<h3>Before sorting with Quick sort</h3>";
                                            $_SESSION['arr01']=randomnumbers();
                                            display($_SESSION['arr01']);
                                           }

                                    function display($array2){
                                        echo "<div class='arrayprint' >";

                                        echo "<table border=1> ";
                                                echo "<tr>";
                                        foreach ($array2 as $key=>$value) {
                                            if ($key%24==0) {

                                                    echo "</tr>";
                                                    echo "<tr>";
                                                }
                                                 echo "
                                                <td>$value</td>
                                                ";
                                        }
                                        echo "</tr></table>
                                                </div>
                                        ";
                                    }

                                    if(isset($_POST['sort'])){
                                        $Sorted=$_POST['sort'];
                                        $new_data=$_SESSION['arr01'];

                                        $start_time=microtime(true);
                                        $found = selectionSort($new_data);
                                        $end_time=microtime(true);
                                        $time=$end_time-$start_time;
                                        $time=($time*0.000001);
                                        if(isset($found)) {
                                            echo "<h3>After sorting with Selection sort</h3>";
                                            echo "<table border=1>
                                                <tr>

                                                <tr>
                                                <td colspan='24'><h3>Execution time is $time seconds</h3></td> ";
                                                echo "<tr>";
                                            foreach ($found as $key=>$values) {
                                                if ($key%24==0) {

                                                    echo "</tr>";
                                                    echo "<tr>";
                                                }
                                                 echo "
                                                <td>$values</td>
                                                ";
                                            }
                                            echo "</tr>";
                                            echo "</table>";
                                        }
                                    }else{
    
                                        $randnums=$_SESSION['arr01'];
                                        $found2=selectionSort($randnums);
                                        if(isset($_POST['sort']) &&isset($found2)){
                                            echo "<h3>After sorting with selection sort</h3>";
                                            $_SESSION['arr01']=$found2;
                                            display($found2);
                                    }
                                }
                                ?>
                            </div>
                            </div>
                            <div class="col-md-3">
                            <h3>Selection Sort</h3>
                            <h4>Algorithm</h4>      
                            <p>
                            For i = 1 to n-1, do //Controls the number of passes
                            min_val = A[ i ],<br/>
                            min_loc = i<br/>
                            For j = i+1 to n, do //Controls the comparisons in each pass
                            If(min_val > A[ j ]), then<br/>
                            min_val = A[ j ]<br/>
                            min_loc = j  <br/>
                            EndIf   <br/>
                            EndFor<br/>
                            If(i != min_loc)<br/>
                            //Swap A[ i ] and A[min_loc]<br/>
                            temp = A[ i ]  <br/>
                            A[ i ] = A[min_loc]<br/>
                            A[min_loc] = temp <br/>
                            EndIf   <br/>
                            EndFor    <br/>
                            <h4>Description</h4>
                            </p>    
                             The algorithm divides the input list into two parts: the sublist of items
                                 already sorted, which is built up from left to right at the front (left) of the list,
                                  and the sublist of items remaining to be sorted that occupy the rest of the list.
                                   Initially, the sorted sublist is empty and the unsorted sublist is the entire input list.
                                    The algorithm proceeds by finding the smallest (or largest, depending on sorting order) element in the unsorted sublist,
                                     exchanging (swapping) it with the leftmost unsorted element (putting it in sorted order),
                                      and moving the sublist boundaries one element to the right. 
                                  occupy
                                  It has O(n<sup>2</sup>) time complexity, making it inefficient on large lists, 
                                  and generally performs worse than the similar insertion sort. 
                                  Selection sort is noted for its simplicity, and it has performance advantage
                                  s over more complicated algorithms in certain situations, particularly where auxiliary memory is limited.

                                                  </p>
                                              <p>
                        </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by Incubee
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Checkbox, Radio & Switch Plugins -->
    <script src="assets/js/bootstrap-checkbox-radio.js"></script>

    <!--  Charts Plugin -->
    <script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
    <script src="assets/js/paper-dashboard.js"></script>

    <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="assets/js/demo.js"></script>


</html>
